# from RabbitSpider import BaseItem
#
#
# class Item(BaseItem):
#     field: str = None
